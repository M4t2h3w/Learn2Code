package com.midnightnoon.pokrocily.vnoreneTriedy.objects;

public interface IHero {
    void Attack();
    void StopAttack();
}
